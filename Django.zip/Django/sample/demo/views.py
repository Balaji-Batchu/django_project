from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

def hi(Response):
	return HttpResponse("Page Not Found")
def hit(Response):
	return HttpResponse("WELCOME TO DJANGO WORKSHOP")
def hello(Response):
	return HttpResponse("from demo")
def dyn(response,name):
	return HttpResponse("hi {}".format(name))
def dynroll(response,number):
	return HttpResponse("hi {}".format(number))
def dynmul(response,a,b):
	return HttpResponse("hi {} your ph.no is {}".format(a,b))
def dynemp(response,name,age,salary,year):
	return HttpResponse("name: {} \n age: {}\n salary:{}\n year: {}".format(name,age,salary,year))